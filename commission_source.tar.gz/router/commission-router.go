package router

import (
	"github.com/QuantumNous/new-api/controller"
	"github.com/QuantumNous/new-api/middleware"

	"github.com/gin-gonic/gin"
)

func SetCommissionRouter(router *gin.Engine) {
	// 用户端返佣API - 需要登录
	commissionRouter := router.Group("/api/user/commission")
	commissionRouter.Use(middleware.TokenAuth())
	{
		// 获取返佣信息
		commissionRouter.GET("/info", controller.GetUserCommissionInfo)

		// 获取返佣明细
		commissionRouter.GET("/logs", controller.GetUserCommissionLogs)

		// 获取返佣统计
		commissionRouter.GET("/stats", controller.GetUserCommissionStats)

		// 转移邀请额度到余额
		commissionRouter.POST("/transfer", controller.TransferCommissionToQuota)

		// 获取消费返佣记录（作为被邀请人）
		commissionRouter.GET("/consumption", controller.GetUserConsumptionLogs)
	}

	// 管理员返佣API - 需要管理员权限
	adminCommissionRouter := router.Group("/api/admin/commission")
	adminCommissionRouter.Use(middleware.AdminAuth())
	{
		// 返佣规则管理
		adminCommissionRouter.GET("/rules", controller.AdminGetCommissionRules)
		adminCommissionRouter.POST("/rules", controller.AdminCreateCommissionRule)
		adminCommissionRouter.PUT("/rules/:id", controller.AdminUpdateCommissionRule)
		adminCommissionRouter.DELETE("/rules/:id", controller.AdminDeleteCommissionRule)
		adminCommissionRouter.PATCH("/rules/:id/toggle", controller.AdminToggleCommissionRule)

		// 返佣统计报表
		adminCommissionRouter.GET("/statistics", controller.AdminGetCommissionStatistics)

		// 返佣日志管理
		adminCommissionRouter.GET("/logs", controller.AdminGetCommissionLogs)

		// 手动结算
		adminCommissionRouter.POST("/settle", controller.AdminSettleCommission)
	}
}
